from django.db import models

# Create your models here.

class Product(models.Model):
    id = models.IntegerField(primary_key=True)
    title = models.CharField(max_length=100, blank=False)
    description = models.CharField(max_length=200, blank=True)
    price = models.IntegerField(blank=False)
    quantity = models.IntegerField()

    def __str__(self):
        return self.title